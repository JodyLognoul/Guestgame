<?php

class LastParties{
	
}


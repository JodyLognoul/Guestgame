<?php

namespace gg\Bundle\PartyBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ggPartyBundle extends Bundle
{
}

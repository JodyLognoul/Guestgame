<?php

namespace gg\Bundle\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ggSiteBundle extends Bundle
{
}
